<?php
        $server='localhost';
        $name='root';
        $pass='';
        $Database='demodb';
        $conn = new mysqli($server,$name,$pass,$Database);
     ?>